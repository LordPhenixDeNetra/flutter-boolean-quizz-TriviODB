
class  QuizzModel{

  var question;
  var correct_answer;
  var incorrect_answer;

  QuizzModel({required this.question, required this.correct_answer, required this.incorrect_answer});

}